# NauseaTitle
it makes your title spin around very very fast.

IT DOES NOT DO ANYTHING ELSE!

## Installation
You can install the mod by:
putting it into your plugins folder

Enjoy! - melon