# Invincibility
This mod makes you invincible and unable to die, you will still flip over when you hit an object

## Installation
You can install the mod by:
putting it into your plugins folder

Enjoy! - melon